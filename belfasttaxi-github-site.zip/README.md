# Belfast Taxi Website

Free static website for GitHub Pages.

## How to use

1. Create a new GitHub repository.
2. Upload `index.html` and `style.css`.
3. Go to Settings > Pages.
4. Under "Build and deployment", choose "Deploy from a branch".
5. Select the `main` branch and `/root`.
6. Save.

Your free website will appear as a GitHub Pages link.
